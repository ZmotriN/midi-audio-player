# midi-audio-player
Javascript Midi Audio Player for WebAudioFonts



https://github.com/surikov/webaudiofont#catalog-of-instruments